const slides = document.querySelectorAll('.slide');
const dots = document.querySelectorAll('.dot');
let currentSlide= 0;

// Function to show Screen 2 and hide Screen 1 after 10 seconds
function showNextScreen() {
    // Get the screen elements by their IDs
    const screen1 = document.getElementById('splash-screen');
    const screen2 = document.getElementById('language-screen');

    // Check if both screen elements exist before manipulating them
    if (screen1 && screen2) {
        // Hide Screen 1 after 10 seconds
        setTimeout(function() {
            screen1.style.display = 'none';
            // Show Screen 2
            screen2.style.display = 'none';
        }, 1000); // 10000 milliseconds = 10 seconds
    } else {
        console.log("Screen elements not found.");
    }
}

const languageButtons = document.querySelectorAll('.language-button');

// Add an event listener to each button
languageButtons.forEach(button => {
    button.addEventListener('click', () => {
        // Change the language or perform any action based on the selected language
        console.log(`Selected language: ${button.textContent}`);
        // You can add functionality here to change app language or navigate to the next screen
    });
});

// Call the function to show the next screen after 10 seconds
showNextScreen();

//for slider
function showSlide(index) {
    slides.forEach((slide, i) => {
      slide.classList.toggle('active', i === index);
      dots[i].classList.toggle('active', i === index);
    });
  }
  
  // Navigate to the next slide
  function nextSlide() {
    if (currentSlide < slides.length - 1) { // Check if not the last slide
      currentSlide++;
      showSlide(currentSlide);
    }
  }
  
  // Navigate to the previous slide
  function prevSlide() {
    if (currentSlide > 0) { // Check if not the first slide
      currentSlide--;
      showSlide(currentSlide);
    }
  }
  
  // Listen for keyboard arrow keys
  document.addEventListener('keydown', (event) => {
    if (event.key === 'ArrowRight') {
      nextSlide(); // Right arrow key
    } else if (event.key === 'ArrowLeft') {
      prevSlide(); // Left arrow key
    }
  });
  
  // Add click event for dots (optional, for manual navigation)
  dots.forEach((dot, index) => {
    dot.addEventListener('click', () => {
      currentSlide = index;
      showSlide(currentSlide);
    });
  });
  
  // Initial display
  showSlide(currentSlide);